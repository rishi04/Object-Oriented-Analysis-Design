﻿$('input.datepicker').datepicker({
    orientation: "top auto",
    autoclose: true
})